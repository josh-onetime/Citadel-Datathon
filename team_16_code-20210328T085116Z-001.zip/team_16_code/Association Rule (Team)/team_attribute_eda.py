# -*- coding: utf-8 -*-
"""
Created on Wed Feb  3 21:44:44 2021

@author: 
"""
import pandas as pd
import numpy as np
import os
import gc
import json
import ast
from datetime import date
from dateutil.relativedelta import relativedelta
os.chdir('E:\\DS\\Python\\citadel\\')



match = pd.read_csv('match.csv')
'''
df = pd.DataFrame(match.isnull().sum())
df.columns = ['count']
df.reset_index( inplace=True)  
df.sort_values(by=['count'], inplace=True)
'''
match['home_result'] = match[['home_team_goal', 'away_team_goal']].apply(lambda x:\
                        'win' if x['home_team_goal'] > x['away_team_goal'] else \
                        ('loss' if x['home_team_goal'] < x['away_team_goal'] else \
                            'draw'), axis=1)

'''
data = match.loc[match["home_result"] == 'win', ['home_team_id','stage','home_result']]
data['home_away']  = 'home'
data.rename(columns={"home_team_id": "team_id", "home_result": "result" },inplace=True)
temp = match.loc[match["home_result"] == 'loss', ['away_team_id','stage','home_result']]
temp['home_away']  = 'away'    
temp.rename(columns={"away_team_id": "team_id", "home_result": "result" },inplace=True)
data = data.append(temp)
'''

data = match[['home_team_id','stage','home_result']]
data.rename(columns={"home_team_id": "team_id", "home_result": "result" },inplace=True)

temp = match[['away_team_id','stage','home_result']]

flip_value = {'win': 1, 'draw':2, 'loss':3}
temp["home_result"] = temp["home_result"].map(flip_value)

flip_value = {1: 'loss', 2:'draw', 3:'win'}
temp["home_result"] = temp["home_result"].map(flip_value)

 
temp.rename(columns={"away_team_id": "team_id", "home_result": "result" },inplace=True)
data = data.append(temp)
data.reset_index(drop=True, inplace=True)

'''
data_set = set(data.team_id)
team_attrib = pd.read_csv('team_attributes.csv')
team_set = set(team_attrib.team_id)

df = pd.DataFrame(team_attrib.isnull().sum())
df.columns = ['count']
df.reset_index( inplace=True)  
df.sort_values(by=['count'], inplace=True)
'''

data = data.merge(team_attrib, left_on = 'team_id', right_on = 'team_id', how= 'left')

data.drop(['team_id', 'buildUpPlayDribbling', 'date'], axis=1, inplace =True)
data.dropna(axis=0, subset=['defenceTeamWidth'], inplace=True)
data.to_csv("team_attrib_match.csv", index=False)

float_cols = [col for col in data.columns.tolist() if data[col].dtypes == 'float64' ]

labels_cols = ['low', 'medium', 'high', 'very_high']
bins_cols = [19, 35, 50, 65, 81]

for col in float_cols:
    data[col] = pd.cut(data[col], bins=bins_cols, labels=labels_cols)

for col in data.columns.tolist():
    data[col] = data[col].astype('category')

data.to_csv("team_attrib_match.csv", index=False)







