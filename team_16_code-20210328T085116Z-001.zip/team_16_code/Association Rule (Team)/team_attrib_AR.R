library(ggplot2)
library(lattice)
#library(caret)
#library(randomForest)
library(plyr)
library(arules)
library(arulesViz)
library(dplyr)


setwd("E:\\DS\\Python\\citadel")
data <- read.csv("team_attrib_match.csv", sep=",",  header= T)
data[] <- lapply( data, factor) 
#rules1 <- apriori(data,parameter = list(minlen=5, supp=0.20, conf=0.6), appearance = list(rhs=c("result=win" ),default="lhs"),control = list(verbose=F))
rules1 <- apriori(data,parameter = list(minlen=10, supp=0.10, conf=0.6), appearance = list(rhs=c("result=win" ),default="lhs"),control = list(verbose=F))

rules1.sorted <- sort(rules1, by="lift")
inspect(head(rules1.sorted, n=100))

# rm redundant  
subset.matrix1 <- is.subset(rules1.sorted, rules1.sorted)
#subset.matrix1[lower.tri(subset.matrix1, diag=T)] <- NA
#redundant1 <- colSums(subset.matrix1, na.rm=T) >= 1
subset.matrix1[lower.tri(subset.matrix1, diag=T)] <- F
redundant1 <- apply(subset.matrix1, 2, any)

#which(redundant1)
rules1.pruned <- rules1.sorted[!redundant1]
inspect(head(rules1.pruned, n=10))

# plot 10 rules

subrules1 <- rules1.pruned[order(-quality(rules1.pruned)$lift, -quality(rules1.pruned)$support),]
subrules1 <- head(subrules1, 10)

png(filename = "E:\\plotrules2.png", width= 480, height= 480, units="px", bg= "transparent")
plot(subrules1, method="graph", control=list(type="items"))
dev.off()


#html creation
p <-plot(subrules1, method="graph", engine = "htmlwidget")
htmlwidgets::saveWidget(p, "armines2.html", selfcontained = FALSE)


