"""
Note that this data preprocessing code is INCOMPLETE. 
This is because certain preprocessing was done with other tools, especially with regards to the elo ratings,
where manual error corrections were required after scrapping from the original data source in excel.

The detailed transformations steps are included in the report. The processed datasets are also available.
"""
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

match = pd.read_csv('match.csv')
player_attributes = pd.read_csv('player_attributes.csv')
player = pd.read_csv('player.csv')
team_attributes = pd.read_csv('team_attributes.csv')

player_attributes['date'] = pd.to_datetime(player_attributes['date'], format='%m/%d/%y %H:%M')
match['date'] = pd.to_datetime(match['date'], format='%m/%d/%y %H:%M')
team_attributes['date'] = pd.to_datetime(team_attributes['date'], format='%m/%d/%y %H:%M')
player['birthday'] = pd.to_datetime(player['birthday'], format='%m/%d/%y %H:%M')

# For information and definitions
# country_id = league_id, since leagues are held in same countries. E.g.France Ligue 1 in France. 
country = pd.read_csv('country.csv')
league = pd.read_csv('league.csv')
team = pd.read_csv('team.csv', encoding = "ISO-8859-1")

player_attributes['preferred_foot'] = player_attributes['preferred_foot'].replace({'left': 0, 'right': 1})
player_attributes['attacking_work_rate'] = player_attributes['attacking_work_rate'].replace({'low': 0, 'medium': 1, 'high': 2, 'None': None, 'norm': None, 'y': None, 'le': None, 'stoc': None})
player_attributes.loc[(player_attributes['defensive_work_rate'] != 'low') & (player_attributes['defensive_work_rate'] != 'medium') & (player_attributes['defensive_work_rate'] != 'high'), 'defensive_work_rate'] = None
player_attributes['defensive_work_rate'] = player_attributes['defensive_work_rate'].replace({'low': 0, 'medium': 1, 'high': 2})

def onehot_encode(df, column):
    df = df.copy()
    dummies = pd.get_dummies(df[column], prefix=column)
    df = pd.concat([df, dummies], axis=1)
    df = df.drop(column, axis=1)
    return df
columns_categorical = ['buildUpPlaySpeedClass', 'buildUpPlayDribblingClass', 'buildUpPlayPassingClass', 'buildUpPlayPositioningClass', 'chanceCreationPassingClass', 'chanceCreationCrossingClass', 'chanceCreationShootingClass', 'chanceCreationPositioningClass', 'defencePressureClass', 'defenceAggressionClass', 'defenceTeamWidthClass', 'defenceDefenderLineClass']
for column in columns_categorical:
    team_attributes = onehot_encode(team_attributes, column=column)
